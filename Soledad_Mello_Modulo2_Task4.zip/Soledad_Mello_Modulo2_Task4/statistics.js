
// Cosa para Senate at glance
var statistics = {
    "Democrats": {
        NoOfReps: 0,
        votedWithParty: 0,
    },
    "Republicans": {
        NoOfReps: 0,
        votedWithParty: 0,
    },
    "Independents": {
        NoOfReps: 0,
        votedWithParty: 0,

    },
    "Total": {
        NoOfReps: data.results[0].num_results,
        votedWithParty: 0,
    },
}